var indexSectionsWithContent =
{
  0: "cgjlmprs",
  1: "cm",
  2: "cgjlmprs"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions"
};

