var searchData=
[
  ['config',['config',['../classconfig.html',1,'']]]
];
