var searchData=
[
  ['junk',['junk',['../classconfig.html#af3601cc6eb1a184fb1cf746a883b8bb5',1,'config::junk()'],['../classmeta.html#a5cf6aca232b3f8cfb979e385803167cd',1,'meta::junk()']]]
];
